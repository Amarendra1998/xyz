package com.example.admin.gogaga;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
ListView l;
Button b,b1;
TextView t,t1;
String[]maintitle={
        "FAQs","Terms And Conditions","Privacy Policy","Feedback"
};
Integer[]imgid={
        R.drawable.hat,R.drawable.hat,R.drawable.hat,R.drawable.hat,
};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);
        RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        LayerDrawable stars = (LayerDrawable) ratingBar.getProgressDrawable();
        stars.getDrawable(2).setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_ATOP);
        b=(Button)findViewById(R.id.button);
       t=(TextView)findViewById(R.id.textView);
       t1=(TextView)findViewById(R.id.textView2);
        Pic adapter=new Pic(this, maintitle,imgid);
        l=(ListView)findViewById(R.id.list);
        l.setAdapter(adapter);
    }
}
