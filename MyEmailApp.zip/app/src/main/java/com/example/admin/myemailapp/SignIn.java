package com.example.admin.myemailapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignIn extends AppCompatActivity {
    Button signout,verify,send;
    private FirebaseAuth mAuth;
    TextView username,userid,status;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        mAuth = FirebaseAuth.getInstance();
        signout = (Button)findViewById(R.id.button7);
        verify = (Button)findViewById(R.id.button6);
        send = (Button)findViewById(R.id.button2) ;
        userid = (TextView)findViewById(R.id.textView6);
        status = (TextView)findViewById(R.id.textView7);
        username = (TextView)findViewById(R.id.textView);
        //check if user is already loggedin
        if (mAuth.getCurrentUser() ==null) {
            finish();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                finish();
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().getCurrentUser()
                        .sendEmailVerification()
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                send.setEnabled(true);

                                if (task.isSuccessful())
                                    Toast.makeText(SignIn.this, "Verification email sent to :"+FirebaseAuth.getInstance().getCurrentUser().getEmail(),Toast.LENGTH_SHORT).show();

                                else
                                    Toast.makeText(SignIn.this,"Fail to send verification email",Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().getCurrentUser()
                        .reload()
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                setInfo();
                            }
                        });
            }
        });
    }
    public void setInfo(){
        FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
        if (user!=null)
        {
            userid.setText(new StringBuilder("UID:").append(user.getUid()));
            status.setText(new StringBuilder("STATUS is:").append(String.valueOf(user.isEmailVerified())));
            username.setText(new StringBuilder("NAME:").append("hello dude!"+" "+String.valueOf(user.getDisplayName())));
        }
        else{
            Toast.makeText(getApplicationContext(),"no user exists",Toast.LENGTH_SHORT).show();
        }
    }

}
